const recordButton = document.getElementById("recordButton");
const stopButton = document.getElementById("stopButton");
const audioElement = document.getElementById("audioElement");
let mediaRecorder;
let audioChunks = [];

recordButton.addEventListener("click", () => {
    navigator.mediaDevices.getUserMedia({ audio: true })
        .then(stream => {
            mediaRecorder = new MediaRecorder(stream);
            mediaRecorder.start();
            mediaRecorder.ondataavailable = event => {
                audioChunks.push(event.data);
            };
        });
});

stopButton.addEventListener("click", () => {
    mediaRecorder.stop();
    mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
        const audioUrl = URL.createObjectURL(audioBlob);
        audioElement.src = audioUrl;
        
        // Convert Blob to Base64 and send to Streamlit
        const reader = new FileReader();
        reader.onloadend = () => {
            const base64Audio = reader.result.split(',')[1];
            fetch("/upload_audio", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ audio: base64Audio })
            });
        };
        reader.readAsDataURL(audioBlob);
    };
});
